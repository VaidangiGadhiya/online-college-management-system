from django.contrib import admin
from managementApp.models import *

# Register your models here.


admin.site.register(contactinformation)
admin.site.register(admissioninfo)
admin.site.register(userregister)



